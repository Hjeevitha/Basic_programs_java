package array;

import java.util.Scanner;

public class array1 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter the sentence");
		String s1=s.nextLine();
		System.out.println(s1);
		
		System.out.println("enter the word");
		String s2=s.next();
		System.out.println(s2);
		
		System.out.println("enter the character");
		char ch=s.next().charAt(0);
		System.out.println(ch);
		
		System.out.println("enter the number");
		int n=s.nextInt();
		System.out.println(n);
		
		System.out.println("enter the decimal");
		double n1=s.nextDouble();
		System.out.println(n1);
		
		

	}

}
