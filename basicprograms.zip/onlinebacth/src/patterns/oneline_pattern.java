package patterns;

public class oneline_pattern {

	public static void main(String[] args) {
		int n=10;
		char ch='A';
		int n2=1;
		
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=n;j++) {
				if(i%2==0) {
					System.out.print(ch+" ");			
				}
				else {
					System.out.print(n2+" ");
				}
			}
			if(i%2!=0) {
				ch++;
			}
			else {
				n2++;
			}
			System.out.println();
		}
		
	}
}
