package number;

public class Extract_lastDigit {

	public static void main(String[] args) {
		int n=5678;
		int rem=n%10;
		System.out.println("last digit of given number "+n+" is "+rem);
		
	}

}
