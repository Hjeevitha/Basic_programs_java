package number;

public class largest_Three_condElseif {
	public static void main(String[] args) {
		int a=20;
		int b=25;
		int c=10;
		int big=(a>b && a>c)?a:(b>c)?b:c;
		
		System.out.println(big);
		
	}

}
