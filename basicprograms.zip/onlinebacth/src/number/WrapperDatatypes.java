package number;

public class WrapperDatatypes {

	public static void main(String[] args) {
		System.out.println(Integer.MIN_VALUE);
		System.out.println(Integer.MAX_VALUE);
		System.out.println("long");
		System.out.println(Long.MIN_VALUE);
		System.out.println(Long.MAX_VALUE);
		System.out.println("double");
		System.out.println(Double.MIN_VALUE);
		System.out.println(Double.MAX_VALUE);

	}

}
