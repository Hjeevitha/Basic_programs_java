package number;

public class Remove_LastDigit {

	public static void main(String[] args) {
		int n=5678;
		int rem=n/10;
		System.out.println("after removeing last digit of given number "+n+" is "+rem);

	}

}
