package number;

public class largest_amoungTwo {

	public static void main(String[] args) {
		int a=30;
		int b=25;
		int big=(a>b)?a:b;
		
		System.out.println(big);

	}

}
